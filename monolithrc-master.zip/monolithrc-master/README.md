# Monolith Resource Collection

This is a collection of utilities and guides related to the MonolithRP server.

For now, there's only a tool to help LEO to calculate fine and jail amounts.

https://apecengo.github.io/monolithrc
