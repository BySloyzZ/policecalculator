<template>
  <footer class="text-gray-600 container mx-auto px-4 text-xs mb-4">
    <p>The Monolith logo and select assets are &copy; Thriving Ventures AB. This site is not affiliated nor endorsed by Thriving Ventures AB.</p>
  </footer>
</template>
