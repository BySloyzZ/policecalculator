<template>
  <div>
    <nuxt />
  </div>
</template>

<style>
body {
  @apply bg-gray-900 antialiased;
}
</style>
